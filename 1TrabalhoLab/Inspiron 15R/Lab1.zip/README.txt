-ENTRADA:

Há um arquivo texto "entrada.txt" que armazena a entrada do programa e é carregado na execução automaticamente.
É necessario apenas inserir as entradas como no modelo do PDF no arquivo de texto e a saída aparecerá como exigido.

Há um exemplo junto a este arquivo .zip de entrada. Por favor, coloque apenas um caso de teste por vez no arquivo de texto.



-COMPILAÇÃO:

Para compilação, apenas digitar "make" no terminal que será feita a (re)compilação e execução do programa.